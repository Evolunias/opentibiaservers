---
title: "Shadow Fiend — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/monsters/shadow-fiend
path: /knowledge/monsters/shadow-fiend
type: monster
collection: knowledge
research_key: knowledge__monsters__shadow-fiend
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Shadow Fiend — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/monsters/shadow-fiend](https://opentibiaservers.com/knowledge/monsters/shadow-fiend)  
> **Research key:** `knowledge__monsters__shadow-fiend`  
> **Collection:** knowledge / monster

## Abstract

Research stub for Open Tibia creature “Shadow Fiend” documented in the OpenTibiaServers knowledge / bestiary catalog.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Shadow Fiend |
| Source URL | https://opentibiaservers.com/knowledge/monsters/shadow-fiend |
| Path | /knowledge/monsters/shadow-fiend |
| Type | monster |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/monsters/shadow-fiend)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/monsters/shadow-fiend. Contact: support@opentibiaservers.com.
