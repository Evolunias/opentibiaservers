---
title: "Malices Horn — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/items/malices-horn
path: /knowledge/items/malices-horn
type: item
collection: knowledge
research_key: knowledge__items__malices-horn
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Malices Horn — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/items/malices-horn](https://opentibiaservers.com/knowledge/items/malices-horn)  
> **Research key:** `knowledge__items__malices-horn`  
> **Collection:** knowledge / item

## Abstract

Research stub for Open Tibia item “Malices Horn” in the OpenTibiaServers knowledge catalog, with canonical backlink to the live knowledge URL.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Malices Horn |
| Source URL | https://opentibiaservers.com/knowledge/items/malices-horn |
| Path | /knowledge/items/malices-horn |
| Type | item |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/items/malices-horn)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/items/malices-horn. Contact: support@opentibiaservers.com.
