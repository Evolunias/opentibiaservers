---
title: "Rukor Zad — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/monsters/rukor-zad
path: /knowledge/monsters/rukor-zad
type: monster
collection: knowledge
research_key: knowledge__monsters__rukor-zad
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Rukor Zad — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/monsters/rukor-zad](https://opentibiaservers.com/knowledge/monsters/rukor-zad)  
> **Research key:** `knowledge__monsters__rukor-zad`  
> **Collection:** knowledge / monster

## Abstract

Research stub for Open Tibia creature “Rukor Zad” documented in the OpenTibiaServers knowledge / bestiary catalog.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Rukor Zad |
| Source URL | https://opentibiaservers.com/knowledge/monsters/rukor-zad |
| Path | /knowledge/monsters/rukor-zad |
| Type | monster |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/monsters/rukor-zad)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/monsters/rukor-zad. Contact: support@opentibiaservers.com.
