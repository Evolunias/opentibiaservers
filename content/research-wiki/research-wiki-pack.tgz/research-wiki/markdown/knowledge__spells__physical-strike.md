---
title: "Physical Strike — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/spells/physical-strike
path: /knowledge/spells/physical-strike
type: spell
collection: knowledge
research_key: knowledge__spells__physical-strike
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Physical Strike — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/spells/physical-strike](https://opentibiaservers.com/knowledge/spells/physical-strike)  
> **Research key:** `knowledge__spells__physical-strike`  
> **Collection:** knowledge / spell

## Abstract

Research stub for Open Tibia spell “Physical Strike” in the OpenTibiaServers spells knowledge catalog.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Physical Strike |
| Source URL | https://opentibiaservers.com/knowledge/spells/physical-strike |
| Path | /knowledge/spells/physical-strike |
| Type | spell |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/spells/physical-strike)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/spells/physical-strike. Contact: support@opentibiaservers.com.
