---
title: "Forked Glacier — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/spells/forked-glacier
path: /knowledge/spells/forked-glacier
type: spell
collection: knowledge
research_key: knowledge__spells__forked-glacier
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Forked Glacier — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/spells/forked-glacier](https://opentibiaservers.com/knowledge/spells/forked-glacier)  
> **Research key:** `knowledge__spells__forked-glacier`  
> **Collection:** knowledge / spell

## Abstract

Research stub for Open Tibia spell “Forked Glacier” in the OpenTibiaServers spells knowledge catalog.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Forked Glacier |
| Source URL | https://opentibiaservers.com/knowledge/spells/forked-glacier |
| Path | /knowledge/spells/forked-glacier |
| Type | spell |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/spells/forked-glacier)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/spells/forked-glacier. Contact: support@opentibiaservers.com.
