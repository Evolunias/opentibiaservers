---
title: "Aquarius Fungius — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/items/aquarius-fungius
path: /knowledge/items/aquarius-fungius
type: item
collection: knowledge
research_key: knowledge__items__aquarius-fungius
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Aquarius Fungius — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/items/aquarius-fungius](https://opentibiaservers.com/knowledge/items/aquarius-fungius)  
> **Research key:** `knowledge__items__aquarius-fungius`  
> **Collection:** knowledge / item

## Abstract

Research stub for Open Tibia item “Aquarius Fungius” in the OpenTibiaServers knowledge catalog, with canonical backlink to the live knowledge URL.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Aquarius Fungius |
| Source URL | https://opentibiaservers.com/knowledge/items/aquarius-fungius |
| Path | /knowledge/items/aquarius-fungius |
| Type | item |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/items/aquarius-fungius)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/items/aquarius-fungius. Contact: support@opentibiaservers.com.
