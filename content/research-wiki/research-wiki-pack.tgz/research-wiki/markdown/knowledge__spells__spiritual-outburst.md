---
title: "Spiritual Outburst — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/spells/spiritual-outburst
path: /knowledge/spells/spiritual-outburst
type: spell
collection: knowledge
research_key: knowledge__spells__spiritual-outburst
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Spiritual Outburst — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/spells/spiritual-outburst](https://opentibiaservers.com/knowledge/spells/spiritual-outburst)  
> **Research key:** `knowledge__spells__spiritual-outburst`  
> **Collection:** knowledge / spell

## Abstract

Research stub for Open Tibia spell “Spiritual Outburst” in the OpenTibiaServers spells knowledge catalog.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Spiritual Outburst |
| Source URL | https://opentibiaservers.com/knowledge/spells/spiritual-outburst |
| Path | /knowledge/spells/spiritual-outburst |
| Type | spell |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/spells/spiritual-outburst)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/spells/spiritual-outburst. Contact: support@opentibiaservers.com.
