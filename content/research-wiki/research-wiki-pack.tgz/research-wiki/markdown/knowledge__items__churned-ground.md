---
title: "Churned Ground — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/items/churned-ground
path: /knowledge/items/churned-ground
type: item
collection: knowledge
research_key: knowledge__items__churned-ground
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Churned Ground — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/items/churned-ground](https://opentibiaservers.com/knowledge/items/churned-ground)  
> **Research key:** `knowledge__items__churned-ground`  
> **Collection:** knowledge / item

## Abstract

Research stub for Open Tibia item “Churned Ground” in the OpenTibiaServers knowledge catalog, with canonical backlink to the live knowledge URL.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Churned Ground |
| Source URL | https://opentibiaservers.com/knowledge/items/churned-ground |
| Path | /knowledge/items/churned-ground |
| Type | item |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/items/churned-ground)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/items/churned-ground. Contact: support@opentibiaservers.com.
