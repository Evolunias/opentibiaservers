---
title: "Rift Pinnacle — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/items/rift-pinnacle
path: /knowledge/items/rift-pinnacle
type: item
collection: knowledge
research_key: knowledge__items__rift-pinnacle
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Rift Pinnacle — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/items/rift-pinnacle](https://opentibiaservers.com/knowledge/items/rift-pinnacle)  
> **Research key:** `knowledge__items__rift-pinnacle`  
> **Collection:** knowledge / item

## Abstract

Research stub for Open Tibia item “Rift Pinnacle” in the OpenTibiaServers knowledge catalog, with canonical backlink to the live knowledge URL.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Rift Pinnacle |
| Source URL | https://opentibiaservers.com/knowledge/items/rift-pinnacle |
| Path | /knowledge/items/rift-pinnacle |
| Type | item |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/items/rift-pinnacle)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/items/rift-pinnacle. Contact: support@opentibiaservers.com.
