---
title: "Folded Green Cake Carpet — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/items/folded-green-cake-carpet
path: /knowledge/items/folded-green-cake-carpet
type: item
collection: knowledge
research_key: knowledge__items__folded-green-cake-carpet
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Folded Green Cake Carpet — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/items/folded-green-cake-carpet](https://opentibiaservers.com/knowledge/items/folded-green-cake-carpet)  
> **Research key:** `knowledge__items__folded-green-cake-carpet`  
> **Collection:** knowledge / item

## Abstract

Research stub for Open Tibia item “Folded Green Cake Carpet” in the OpenTibiaServers knowledge catalog, with canonical backlink to the live knowledge URL.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Folded Green Cake Carpet |
| Source URL | https://opentibiaservers.com/knowledge/items/folded-green-cake-carpet |
| Path | /knowledge/items/folded-green-cake-carpet |
| Type | item |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/items/folded-green-cake-carpet)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/items/folded-green-cake-carpet. Contact: support@opentibiaservers.com.
