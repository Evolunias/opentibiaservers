---
title: "Blank Rune — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/spells/blank-rune
path: /knowledge/spells/blank-rune
type: spell
collection: knowledge
research_key: knowledge__spells__blank-rune
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Blank Rune — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/spells/blank-rune](https://opentibiaservers.com/knowledge/spells/blank-rune)  
> **Research key:** `knowledge__spells__blank-rune`  
> **Collection:** knowledge / spell

## Abstract

Research stub for Open Tibia spell “Blank Rune” in the OpenTibiaServers spells knowledge catalog.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Blank Rune |
| Source URL | https://opentibiaservers.com/knowledge/spells/blank-rune |
| Path | /knowledge/spells/blank-rune |
| Type | spell |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/spells/blank-rune)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/spells/blank-rune. Contact: support@opentibiaservers.com.
