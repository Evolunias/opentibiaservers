---
title: "Executioners Throw — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/spells/executioners-throw
path: /knowledge/spells/executioners-throw
type: spell
collection: knowledge
research_key: knowledge__spells__executioners-throw
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Executioners Throw — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/spells/executioners-throw](https://opentibiaservers.com/knowledge/spells/executioners-throw)  
> **Research key:** `knowledge__spells__executioners-throw`  
> **Collection:** knowledge / spell

## Abstract

Research stub for Open Tibia spell “Executioners Throw” in the OpenTibiaServers spells knowledge catalog.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Executioners Throw |
| Source URL | https://opentibiaservers.com/knowledge/spells/executioners-throw |
| Path | /knowledge/spells/executioners-throw |
| Type | spell |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/spells/executioners-throw)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/spells/executioners-throw. Contact: support@opentibiaservers.com.
