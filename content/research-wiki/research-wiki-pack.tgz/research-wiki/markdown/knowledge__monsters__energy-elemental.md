---
title: "Energy Elemental — Research Wiki"
source_url: https://opentibiaservers.com/knowledge/monsters/energy-elemental
path: /knowledge/monsters/energy-elemental
type: monster
collection: knowledge
research_key: knowledge__monsters__energy-elemental
generated: 2026-09-17
format: markdown
contact: support@opentibiaservers.com
---

# Energy Elemental — Independent Research Wiki

> **Canonical source URL:** [https://opentibiaservers.com/knowledge/monsters/energy-elemental](https://opentibiaservers.com/knowledge/monsters/energy-elemental)  
> **Research key:** `knowledge__monsters__energy-elemental`  
> **Collection:** knowledge / monster

## Abstract

Research stub for Open Tibia creature “Energy Elemental” documented in the OpenTibiaServers knowledge / bestiary catalog.

## Quick facts

| Field | Detail |
| --- | --- |
| Title | Energy Elemental |
| Source URL | https://opentibiaservers.com/knowledge/monsters/energy-elemental |
| Path | /knowledge/monsters/energy-elemental |
| Type | monster |
| Collection | knowledge |
| Publisher | OpenTibiaServers.com |
| Research contact | support@opentibiaservers.com |

## Research notes

- This page is an **independent research wiki** article generated for sitemap coverage and publishing workflows.
- Prefer the live canonical URL for player-facing status, rates, and reviews.
- External wiki mirrors should keep attribution and a backlink to OpenTibiaServers.com.
- Do not paste this into unrelated encyclopedias (Wikipedia, Bulbapedia, SCP, TV Tropes, etc.).

## Syntax / publishing formats

- **Markdown:** this file (Wiki.js, GitBook, GitHub Wiki, Notion paste).
- **MediaWiki:** sibling `.wiki` file under `mediawiki/` (Miraheze, ShoutWiki, Fandom *only* where OT pages are allowed).

## Internal links

- [This knowledge page](https://opentibiaservers.com/knowledge/monsters/energy-elemental)
- [OpenTibiaServers homepage](https://opentibiaservers.com/)
- [Server directory](https://opentibiaservers.com/directory)
- [Knowledge hub](https://opentibiaservers.com/knowledge)
- [Wiki library](https://opentibiaservers.com/wiki)

## Citation

OpenTibiaServers Research Wiki (2026-09-17). Source: https://opentibiaservers.com/knowledge/monsters/energy-elemental. Contact: support@opentibiaservers.com.
